<template>
  <div class="surface-section px-4 py-8 md:px-6 lg:px-8 text-center">
    <div class="mb-3 font-bold text-3xl">
      <span class="text-900">Many Features </span>
      <span class="text-blue-600">Many Solutions</span>
    </div>
    <div class="text-700 mb-6">
    </div>
    <div class="grid">
      <div class="col-12 md:col-4 mb-4 px-5">
        <span
          class="p-3 shadow-2 mb-3 inline-block surface-card"
          style="border-radius: 10px"
        >
          <i class="pi pi-desktop text-4xl text-blue-500"></i>
        </span>
        <div class="text-900 text-xl mb-3 font-medium">
          Built for Developers
        </div>
        <span class="text-700 line-height-3"
          >
          Fitur ini menunjukkan bahwa website course ini dibuat khusus untuk para developer. Mereka akan merasa nyaman dan terfasilitasi dengan adanya fitur-fitur yang sesuai dengan kebutuhan seorang developer.
          </span
        >
      </div>
      <div class="col-12 md:col-4 mb-4 px-5">
        <span
          class="p-3 shadow-2 mb-3 inline-block surface-card"
          style="border-radius: 10px"
        >
          <i class="pi pi-lock text-4xl text-blue-500"></i>
        </span>
        <div class="text-900 text-xl mb-3 font-medium">
          End-to-End Encryption
        </div>
        <span class="text-700 line-height-3"
          >
          Fitur ini memberikan keamanan tingkat tinggi pada data dan informasi yang dikirimkan selama proses pembelajaran. Ini penting untuk menjaga privasi dan melindungi data pengguna dari ancaman keamanan yang mungkin terjadi.
          </span
        >
      </div>
      <div class="col-12 md:col-4 mb-4 px-5">
        <span
          class="p-3 shadow-2 mb-3 inline-block surface-card"
          style="border-radius: 10px"
        >
          <i class="pi pi-check-circle text-4xl text-blue-500"></i>
        </span>
        <div class="text-900 text-xl mb-3 font-medium">Easy to Use</div>
        <span class="text-700 line-height-3"
          >
          Dengan interface yang mudah dipahami, setiap orang akan dapat mengakses dan mengikuti course yang tersedia dengan mudah.
          </span
        >
      </div>
      <div class="col-12 md:col-4 mb-4 px-5">
        <span
          class="p-3 shadow-2 mb-3 inline-block surface-card"
          style="border-radius: 10px"
        >
          <i class="pi pi-globe text-4xl text-blue-500"></i>
        </span>
        <div class="text-900 text-xl mb-3 font-medium">
          Fast & Global Support
        </div>
        <span class="text-700 line-height-3"
          >
          Fitur ini memberikan dukungan cepat dan global bagi pengguna yang membutuhkan bantuan atau solusi terkait dengan course yang diikuti.
          </span
        >
      </div>
      <div class="col-12 md:col-4 mb-4 px-5">
        <span
          class="p-3 shadow-2 mb-3 inline-block surface-card"
          style="border-radius: 10px"
        >
          <i class="pi pi-github text-4xl text-blue-500"></i>
        </span>
        <div class="text-900 text-xl mb-3 font-medium">Open Source</div>
        <span class="text-700 line-height-3">
            Website course yang open source memungkinkan para developer untuk terus mengembangkan dan memperbarui fitur-fitur yang ada, sehingga memberikan pengalaman belajar yang lebih baik bagi pengguna.
        </span>
      </div>
      <div class="col-12 md:col-4 md:mb-4 mb-0 px-3">
        <span
          class="p-3 shadow-2 mb-3 inline-block surface-card"
          style="border-radius: 10px"
        >
          <i class="pi pi-shield text-4xl text-blue-500"></i>
        </span>
        <div class="text-900 text-xl mb-3 font-medium">Trusted Security</div>
        <span class="text-700 line-height-3"
          >
          Dengan fitur-fitur keamanan yang terpercaya, pengguna dapat merasa nyaman dan aman saat mengikuti course yang tersedia pada website ini.
          </span
        >
      </div>
    </div>
  </div>
</template>

<script>
export default {
    components:{
        
    }
};
</script>

<style>

</style>
