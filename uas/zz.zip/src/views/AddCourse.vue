<template>
  <div>
    <Courseau />
    <eventaut />
  </div>
</template>

<script>
import Courseau from '@/components/Courseau.vue';
import eventaut from '@/components/eventaut.vue';
export default {
    components:{
        Courseau,
        eventaut
    }
}
</script>

<style>

</style>