<template>
  <Course />
</template>

<script>
import Course from "@/components/Course.vue";
export default {
  components: {
    Course,
  },
};
</script>

<style></style>
