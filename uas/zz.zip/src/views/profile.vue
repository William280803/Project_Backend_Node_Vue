<template>
    <profilecom />
</template>

<script>
import profilecom from '@/components/profilecom.vue';
export default {
    components:{
        profilecom
    }
};
</script>

<style></style>
