<template>
    <CourseF />
</template>

<script>
import CourseF from '@/components/CourseF.vue';
export default {
    components:{
        CourseF,
    },
}
</script>

<style>

</style>