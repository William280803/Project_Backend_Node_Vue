<template>
    <Cal />
</template>
  
  <script>
  import Cal from '@/components/Cal.vue';
  export default {
      components:{
          Cal,

      }
  }
  </script>
  
  <style>
  
  </style>